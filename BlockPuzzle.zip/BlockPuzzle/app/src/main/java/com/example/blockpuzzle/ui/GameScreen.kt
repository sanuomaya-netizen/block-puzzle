package com.example.blockpuzzle.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.blockpuzzle.game.GameEngine
import com.example.blockpuzzle.game.GameEvent
import com.example.blockpuzzle.game.GameViewModel
import com.example.blockpuzzle.game.Piece
import kotlin.math.roundToInt

@Composable
fun GameScreen(vm: GameViewModel, theme: BlockTheme, onExitToMenu: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val vibrationOn by rememberUpdatedState(settings.vibrationEnabled)
    val density = LocalDensity.current

    // Haptics on valid placement / clear (if enabled in settings).
    LaunchedEffect(Unit) {
        vm.events.collect { event ->
            if (vibrationOn) {
                when (event) {
                    GameEvent.PLACED -> haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    GameEvent.CLEARED, GameEvent.GAME_OVER ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
            }
        }
    }

    BackHandler(enabled = !state.gameOver) { vm.setPaused(!state.paused) }

    // Line clear animation progress (0..1).
    val clearAnim = remember { Animatable(0f) }
    LaunchedEffect(state.clearing) {
        if (state.clearing.isNotEmpty()) {
            clearAnim.snapTo(0f)
            clearAnim.animateTo(1f, tween(280))
        } else {
            clearAnim.snapTo(0f)
        }
    }

    // Drag state, all in root coordinates.
    var dragIndex by remember { mutableStateOf<Int?>(null) }
    var finger by remember { mutableStateOf(Offset.Zero) }
    var boardOrigin by remember { mutableStateOf(Offset.Zero) }
    var rootOrigin by remember { mutableStateOf(Offset.Zero) }
    val slotOrigins = remember { mutableStateListOf(Offset.Zero, Offset.Zero, Offset.Zero) }
    val stateRef by rememberUpdatedState(state)

    LaunchedEffect(state.paused, state.gameOver) { dragIndex = null }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { rootOrigin = it.positionInRoot() }
    ) {
        val landscape = maxWidth > maxHeight
        val boardDp: Dp
        val slotDp: Dp
        if (landscape) {
            boardDp = minOf(maxHeight - 24.dp, maxWidth * 0.5f).coerceAtLeast(120.dp)
            slotDp = minOf((maxWidth - boardDp - 56.dp) / 3f, maxHeight - 170.dp).coerceAtLeast(60.dp)
        } else {
            boardDp = minOf(maxWidth - 32.dp, (maxHeight - 150.dp) * 0.75f).coerceAtLeast(120.dp)
            slotDp = boardDp / 3f
        }
        val trayCellDp = slotDp / 5.4f
        val cellPx = with(density) { boardDp.toPx() } / GameEngine.SIZE
        val cellState = rememberUpdatedState(cellPx)

        // While dragging, the piece floats above the finger so the finger does not hide it.
        fun dragTopLeft(piece: Piece, f: Offset): Offset {
            val cell = cellState.value
            return Offset(
                f.x - piece.shape.width * cell / 2f,
                f.y - cell * 1.2f - piece.shape.height * cell
            )
        }

        /** The snapped board position under the dragged piece, or null if it is not over the board. */
        fun targetFor(idx: Int, f: Offset): Ghost? {
            val st = stateRef
            val piece = st.tray.getOrNull(idx) ?: return null
            val cell = cellState.value
            val tl = dragTopLeft(piece, f)
            val col = ((tl.x - boardOrigin.x) / cell).roundToInt()
            val row = ((tl.y - boardOrigin.y) / cell).roundToInt()
            if (row !in 0..GameEngine.SIZE - piece.shape.height) return null
            if (col !in 0..GameEngine.SIZE - piece.shape.width) return null
            return Ghost(row, col, piece.shape, GameEngine.canPlace(st.board, piece.shape, row, col))
        }

        val ghost = dragIndex?.let { targetFor(it, finger) }

        val boardBox: @Composable () -> Unit = {
            Box(
                Modifier
                    .size(boardDp)
                    .onGloballyPositioned { boardOrigin = it.positionInRoot() }
            ) {
                BoardView(
                    board = state.board,
                    clearing = state.clearing,
                    clearProgress = clearAnim.value,
                    ghost = ghost,
                    theme = theme,
                    modifier = Modifier.fillMaxSize()
                )
                state.popup?.let { ScorePopupText(it, Modifier.align(Alignment.Center)) }
            }
        }

        val trayRow: @Composable () -> Unit = {
            Row {
                for (i in 0 until 3) {
                    val piece = state.tray.getOrNull(i)
                    Box(
                        Modifier
                            .size(slotDp)
                            .padding(4.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .onGloballyPositioned { slotOrigins[i] = it.positionInRoot() }
                            .then(
                                if (piece != null) {
                                    Modifier.pointerInput(piece) {
                                        detectDragGestures(
                                            onDragStart = { offset ->
                                                if (!stateRef.busy) {
                                                    dragIndex = i
                                                    finger = slotOrigins[i] + offset
                                                }
                                            },
                                            onDragEnd = {
                                                val idx = dragIndex
                                                if (idx != null) {
                                                    val t = targetFor(idx, finger)
                                                    if (t != null && t.valid) vm.placePiece(idx, t.row, t.col)
                                                }
                                                dragIndex = null
                                            },
                                            onDragCancel = { dragIndex = null },
                                            onDrag = { change, _ ->
                                                change.consume()
                                                if (dragIndex == i) finger = slotOrigins[i] + change.position
                                            }
                                        )
                                    }
                                } else {
                                    Modifier
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (piece != null) {
                            PieceView(
                                piece = piece,
                                cellSize = trayCellDp,
                                theme = theme,
                                alpha = if (dragIndex == i) 0.25f else 1f
                            )
                        }
                    }
                }
            }
        }

        val topBar: @Composable () -> Unit = {
            TopBar(
                score = state.score,
                best = maxOf(settings.highScore, state.score),
                onPause = { vm.setPaused(true) }
            )
        }

        if (landscape) {
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                boardBox()
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    topBar()
                    ComboIndicator(state.combo)
                    Spacer(Modifier.height(16.dp))
                    trayRow()
                }
            }
        } else {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                topBar()
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    ComboIndicator(state.combo)
                    Spacer(Modifier.height(8.dp))
                    boardBox()
                    Spacer(Modifier.height(16.dp))
                    trayRow()
                }
            }
        }

        // Dragged piece overlay (drawn last so it is on top of everything).
        val dragging = dragIndex?.let { state.tray.getOrNull(it) }
        if (dragging != null) {
            val tl = dragTopLeft(dragging, finger)
            PieceView(
                piece = dragging,
                cellSize = with(density) { cellState.value.toDp() },
                theme = theme,
                modifier = Modifier.offset {
                    IntOffset(
                        (tl.x - rootOrigin.x).roundToInt(),
                        (tl.y - rootOrigin.y).roundToInt()
                    )
                },
                alpha = 0.95f
            )
        }
    }

    if (state.gameOver) {
        GameOverDialog(
            score = state.score,
            highScore = settings.highScore,
            newRecord = state.newRecord,
            onPlayAgain = { vm.newGame() },
            onMainMenu = onExitToMenu
        )
    } else if (state.paused) {
        PauseDialog(
            onResume = { vm.setPaused(false) },
            onRestart = { vm.newGame() },
            onMainMenu = onExitToMenu
        )
    }
}

@Composable
private fun TopBar(score: Int, best: Int, onPause: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalIconButton(onClick = onPause) {
            Icon(Icons.Filled.Pause, contentDescription = "Pause")
        }
        Spacer(Modifier.weight(1f))
        StatBox("SCORE", score)
        Spacer(Modifier.width(24.dp))
        StatBox("BEST", best)
    }
}

@Composable
private fun StatBox(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.End) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
        Text(
            "$value",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ComboIndicator(combo: Int) {
    var lastShown by remember { mutableIntStateOf(2) }
    SideEffect { if (combo >= 2) lastShown = combo }
    Box(Modifier.height(32.dp), contentAlignment = Alignment.Center) {
        AnimatedVisibility(
            visible = combo >= 2,
            enter = scaleIn() + fadeIn(),
            exit = fadeOut()
        ) {
            Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary) {
                Text(
                    "COMBO x${lastShown.coerceAtMost(3)}",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
