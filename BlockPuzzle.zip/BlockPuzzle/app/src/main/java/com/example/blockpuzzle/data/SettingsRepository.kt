package com.example.blockpuzzle.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "block_puzzle_settings")

data class AppSettings(
    val highScore: Int = 0,
    val theme: String = "Classic",
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val musicEnabled: Boolean = true
)

class SettingsRepository(context: Context) {
    private val store = context.applicationContext.dataStore

    private object Keys {
        val HIGH_SCORE = intPreferencesKey("highScore")
        val THEME = stringPreferencesKey("selectedTheme")
        val SOUND = booleanPreferencesKey("soundEnabled")
        val VIBRATION = booleanPreferencesKey("vibrationEnabled")
        val MUSIC = booleanPreferencesKey("musicEnabled")
    }

    val settings: Flow<AppSettings> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            AppSettings(
                highScore = p[Keys.HIGH_SCORE] ?: 0,
                theme = p[Keys.THEME] ?: "Classic",
                soundEnabled = p[Keys.SOUND] ?: true,
                vibrationEnabled = p[Keys.VIBRATION] ?: true,
                musicEnabled = p[Keys.MUSIC] ?: true
            )
        }

    suspend fun setHighScore(value: Int) { store.edit { it[Keys.HIGH_SCORE] = value } }
    suspend fun setTheme(name: String) { store.edit { it[Keys.THEME] = name } }
    suspend fun setSoundEnabled(on: Boolean) { store.edit { it[Keys.SOUND] = on } }
    suspend fun setVibrationEnabled(on: Boolean) { store.edit { it[Keys.VIBRATION] = on } }
    suspend fun setMusicEnabled(on: Boolean) { store.edit { it[Keys.MUSIC] = on } }
}
