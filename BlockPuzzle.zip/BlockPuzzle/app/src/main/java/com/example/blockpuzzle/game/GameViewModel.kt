package com.example.blockpuzzle.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.blockpuzzle.data.AppSettings
import com.example.blockpuzzle.data.SettingsRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ScorePopup(val id: Long, val text: String)

data class GameUiState(
    val board: Board,
    val tray: List<Piece?>,
    val score: Int = 0,
    /** Number of consecutive placements that cleared at least one line. */
    val combo: Int = 0,
    /** Cell keys (row * 8 + col) currently playing the clear animation. */
    val clearing: Set<Int> = emptySet(),
    val popup: ScorePopup? = null,
    val busy: Boolean = false,
    val paused: Boolean = false,
    val gameOver: Boolean = false,
    val newRecord: Boolean = false
)

enum class GameEvent { PLACED, CLEARED, GAME_OVER }

class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)
    private val sound = SoundManager()

    val settings: StateFlow<AppSettings> = repo.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _state = MutableStateFlow(freshState())
    val state: StateFlow<GameUiState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<GameEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<GameEvent> = _events.asSharedFlow()

    private var popupCounter = 0L
    private var bestAtStart = 0
    private var clearJob: Job? = null

    private fun freshState(): GameUiState {
        val board = GameEngine.emptyBoard()
        return GameUiState(board = board, tray = GameEngine.generateSet(board))
    }

    fun newGame() {
        clearJob?.cancel()
        bestAtStart = settings.value.highScore
        _state.value = freshState()
    }

    fun setPaused(paused: Boolean) {
        _state.update { if (it.gameOver) it else it.copy(paused = paused) }
    }

    fun placePiece(trayIndex: Int, row: Int, col: Int) {
        val s = _state.value
        if (s.gameOver || s.paused || s.busy) return
        val piece = s.tray.getOrNull(trayIndex) ?: return
        if (!GameEngine.canPlace(s.board, piece.shape, row, col)) return

        val placed = GameEngine.place(s.board, piece, row, col)
        val (rows, cols) = GameEngine.fullLines(placed)
        val lines = rows.size + cols.size
        val newTray = s.tray.toMutableList().also { it[trayIndex] = null }
        var gained = piece.shape.cells.size // +1 per block placed

        if (lines == 0) {
            // No clear: combo resets.
            _state.value = s.copy(board = placed, tray = newTray, score = s.score + gained, combo = 0)
            playSound { place() }
            _events.tryEmit(GameEvent.PLACED)
            finishTurn()
            return
        }

        val combo = s.combo + 1
        val multiplier = combo.coerceAtMost(3) // 1x, 2x, 3x+
        gained += 10 * lines * lines * multiplier
        val cells = GameEngine.cellsOf(rows, cols)
        val label = when (lines) {
            1 -> ""
            2 -> "Double! "
            3 -> "Triple! "
            4 -> "Quad! "
            else -> "Amazing! "
        }
        val popup = ScorePopup(++popupCounter, "$label+$gained")

        _state.value = s.copy(
            board = placed,
            tray = newTray,
            score = s.score + gained,
            combo = combo,
            clearing = cells,
            popup = popup,
            busy = true
        )
        playSound { clear() }
        _events.tryEmit(GameEvent.CLEARED)

        clearJob = viewModelScope.launch {
            delay(CLEAR_ANIMATION_MS)
            _state.update { it.copy(board = GameEngine.clear(it.board, cells), clearing = emptySet(), busy = false) }
            finishTurn()
        }
    }

    /** Refills the tray if empty, saves the high score, and checks for game over. */
    private fun finishTurn() {
        val s = _state.value
        var tray = s.tray
        if (tray.all { it == null }) tray = GameEngine.generateSet(s.board)
        val over = tray.filterNotNull().none { GameEngine.canPlaceAnywhere(s.board, it.shape) }

        if (s.score > settings.value.highScore) {
            viewModelScope.launch { repo.setHighScore(s.score) }
        }
        _state.value = s.copy(
            tray = tray,
            gameOver = over,
            newRecord = over && s.score > bestAtStart
        )
        if (over) {
            playSound { gameOver() }
            _events.tryEmit(GameEvent.GAME_OVER)
        }
    }

    private inline fun playSound(block: SoundManager.() -> Unit) {
        if (settings.value.soundEnabled) sound.block()
    }

    override fun onCleared() {
        sound.release()
        super.onCleared()
    }

    private companion object {
        const val CLEAR_ANIMATION_MS = 300L
    }
}
