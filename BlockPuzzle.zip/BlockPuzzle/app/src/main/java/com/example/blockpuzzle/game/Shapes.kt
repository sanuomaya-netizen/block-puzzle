package com.example.blockpuzzle.game

/** 8x8 board. 0 = empty, 1..5 = filled with that colour index (so "filled" == value != 0). */
typealias Board = List<List<Int>>

/**
 * A block shape defined by a text pattern ('#' = filled).
 * [grid] is the 2D Boolean array form; [cells] is the same data as (row, col) pairs.
 */
class Shape(val id: String, pattern: List<String>) {
    val height: Int = pattern.size
    val width: Int = pattern.maxOf { it.length }
    val grid: Array<BooleanArray> = Array(height) { r ->
        BooleanArray(width) { c -> pattern[r].getOrNull(c) == '#' }
    }
    val cells: List<Pair<Int, Int>> = buildList {
        for (r in 0 until height) for (c in 0 until width) if (grid[r][c]) add(r to c)
    }
}

/** A piece in the tray: a shape plus the colour slot (1..5) it will be drawn with. */
data class Piece(val shape: Shape, val colorIdx: Int)

object Shapes {
    val single = Shape("1x1", listOf("#"))

    val all: List<Shape> = listOf(
        single,
        // straight lines
        Shape("1x2", listOf("##")),
        Shape("2x1", listOf("#", "#")),
        Shape("1x3", listOf("###")),
        Shape("3x1", listOf("#", "#", "#")),
        Shape("1x4", listOf("####")),
        Shape("4x1", listOf("#", "#", "#", "#")),
        Shape("1x5", listOf("#####")),
        Shape("5x1", listOf("#", "#", "#", "#", "#")),
        // rectangles
        Shape("2x2", listOf("##", "##")),
        Shape("2x3", listOf("###", "###")),
        Shape("3x2", listOf("##", "##", "##")),
        Shape("3x3", listOf("###", "###", "###")),
        // 3-block L, 4 rotations
        Shape("L0", listOf("#.", "##")),
        Shape("L1", listOf(".#", "##")),
        Shape("L2", listOf("##", "#.")),
        Shape("L3", listOf("##", ".#")),
        // T, 4 rotations
        Shape("T0", listOf("###", ".#.")),
        Shape("T1", listOf(".#.", "###")),
        Shape("T2", listOf("#.", "##", "#.")),
        Shape("T3", listOf(".#", "##", ".#")),
        // S, 2 rotations
        Shape("S0", listOf(".##", "##.")),
        Shape("S1", listOf("#.", "##", ".#")),
        // Z, 2 rotations
        Shape("Z0", listOf("##.", ".##")),
        Shape("Z1", listOf(".#", "##", "#."))
    )
}
