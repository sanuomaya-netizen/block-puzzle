package com.example.blockpuzzle

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.blockpuzzle.ads.AppOpenAdManager
import com.example.blockpuzzle.game.GameViewModel
import com.example.blockpuzzle.ui.BlockPuzzleTheme
import com.example.blockpuzzle.ui.GameScreen
import com.example.blockpuzzle.ui.MenuScreen
import com.example.blockpuzzle.ui.SettingsScreen
import com.example.blockpuzzle.ui.SettingsViewModel
import com.example.blockpuzzle.ui.SplashScreen
import com.example.blockpuzzle.ui.Themes

private enum class Screen { Splash, Menu, Game, Settings }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val adManager = (application as BlockPuzzleApp).adManager
        setContent { AppRoot(adManager) }
    }
}

@Composable
private fun AppRoot(adManager: AppOpenAdManager) {
    val settingsVm: SettingsViewModel = viewModel()
    val gameVm: GameViewModel = viewModel()
    val settings by settingsVm.settings.collectAsStateWithLifecycle()
    val theme = Themes.byName(settings.theme)
    var screen by rememberSaveable { mutableStateOf(Screen.Splash) }

    BlockPuzzleTheme(theme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Box(Modifier.fillMaxSize().safeDrawingPadding()) {
                when (screen) {
                    Screen.Splash -> SplashScreen(adManager, theme) { screen = Screen.Menu }

                    Screen.Menu -> MenuScreen(
                        highScore = settings.highScore,
                        theme = theme,
                        onPlay = {
                            gameVm.newGame()
                            screen = Screen.Game
                        },
                        onSettings = { screen = Screen.Settings }
                    )

                    Screen.Game -> GameScreen(
                        vm = gameVm,
                        theme = theme,
                        onExitToMenu = { screen = Screen.Menu }
                    )

                    Screen.Settings -> SettingsScreen(
                        settings = settings,
                        onTheme = settingsVm::setTheme,
                        onSound = settingsVm::setSound,
                        onVibration = settingsVm::setVibration,
                        onResetHighScore = settingsVm::resetHighScore,
                        onBack = { screen = Screen.Menu }
                    )
                }
            }
        }
    }
}
