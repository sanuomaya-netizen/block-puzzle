package com.example.blockpuzzle.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.blockpuzzle.ads.AppOpenAdManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * Splash: logo + spinner. Waits (max 4 s) for the single App Open Ad, shows it once,
 * then navigates on when it is dismissed, fails, or is unavailable.
 */
@Composable
fun SplashScreen(adManager: AppOpenAdManager, theme: BlockTheme, onFinished: () -> Unit) {
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        val started = System.currentTimeMillis()
        withTimeoutOrNull(4000L) { while (!adManager.loadFinished) delay(100) }
        val elapsed = System.currentTimeMillis() - started
        if (elapsed < 1200L) delay(1200L - elapsed) // keep the logo visible briefly

        val activity = context.findActivity()
        var done = false
        val finish: () -> Unit = {
            if (!done) {
                done = true
                onFinished()
            }
        }
        if (activity != null && adManager.adReady) adManager.showOnce(activity) { finish() } else finish()
    }

    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Canvas(Modifier.size(96.dp)) {
            val cell = size.width / 2f
            val gap = cell * 0.08f
            val side = cell - gap * 2f
            val radius = CornerRadius(cell * 0.2f)
            for (i in 0 until 4) {
                val r = i / 2
                val c = i % 2
                drawRoundRect(
                    theme.blocks[i],
                    Offset(c * cell + gap, r * cell + gap),
                    Size(side, side),
                    radius
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(
            "Block Puzzle",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(24.dp))
        CircularProgressIndicator()
    }
}
