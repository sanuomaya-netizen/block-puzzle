package com.example.blockpuzzle.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.example.blockpuzzle.game.Board
import com.example.blockpuzzle.game.GameEngine
import com.example.blockpuzzle.game.Piece
import com.example.blockpuzzle.game.ScorePopup
import com.example.blockpuzzle.game.Shape

/** Ghost preview shown on the board while dragging. */
data class Ghost(val row: Int, val col: Int, val shape: Shape, val valid: Boolean)

private val GhostValid = Color(0xFF4CAF50)
private val GhostInvalid = Color(0xFFF44336)

private fun DrawScope.drawBlock(topLeft: Offset, cell: Float, color: Color, scale: Float = 1f) {
    val inset = cell * 0.05f + cell * (1f - scale) / 2f
    val side = cell - 2f * inset
    if (side <= 0f) return
    val origin = Offset(topLeft.x + inset, topLeft.y + inset)
    val radius = CornerRadius(cell * 0.18f)
    drawRoundRect(color, origin, Size(side, side), radius)
    // subtle top highlight for a bit of depth
    drawRoundRect(Color.White.copy(alpha = 0.18f * color.alpha), origin, Size(side, side * 0.45f), radius)
}

@Composable
fun PieceView(
    piece: Piece,
    cellSize: Dp,
    theme: BlockTheme,
    modifier: Modifier = Modifier,
    alpha: Float = 1f
) {
    val color = theme.blocks[(piece.colorIdx - 1).coerceIn(0, theme.blocks.lastIndex)].copy(alpha = alpha)
    Canvas(modifier.size(cellSize * piece.shape.width, cellSize * piece.shape.height)) {
        val cell = size.width / piece.shape.width
        for ((r, c) in piece.shape.cells) drawBlock(Offset(c * cell, r * cell), cell, color)
    }
}

@Composable
fun BoardView(
    board: Board,
    clearing: Set<Int>,
    clearProgress: Float,
    ghost: Ghost?,
    theme: BlockTheme,
    modifier: Modifier = Modifier
) {
    val dark = isSystemInDarkTheme()
    val boardBg = MaterialTheme.colorScheme.surfaceVariant
    val emptyCell = if (dark) Color.White.copy(alpha = 0.07f) else Color.Black.copy(alpha = 0.07f)

    Canvas(modifier) {
        val n = GameEngine.SIZE
        val cell = size.width / n
        drawRoundRect(boardBg, cornerRadius = CornerRadius(cell * 0.3f))

        for (r in 0 until n) {
            for (c in 0 until n) {
                val topLeft = Offset(c * cell, r * cell)
                val v = board[r][c]
                if (v == 0) {
                    drawBlockPlain(topLeft, cell, emptyCell)
                    continue
                }
                val base = theme.blocks[(v - 1).coerceIn(0, theme.blocks.lastIndex)]
                if ((r * n + c) in clearing) {
                    // flash to white, grow slightly and fade out
                    val p = clearProgress
                    val tinted = lerp(base, Color.White, (p * 2f).coerceAtMost(1f))
                    drawBlock(topLeft, cell, tinted.copy(alpha = 1f - p), scale = 1f + 0.25f * p)
                } else {
                    drawBlock(topLeft, cell, base)
                }
            }
        }

        if (ghost != null) {
            val color = (if (ghost.valid) GhostValid else GhostInvalid).copy(alpha = 0.55f)
            for ((dr, dc) in ghost.shape.cells) {
                drawBlock(Offset((ghost.col + dc) * cell, (ghost.row + dr) * cell), cell, color)
            }
        }
    }
}

private fun DrawScope.drawBlockPlain(topLeft: Offset, cell: Float, color: Color) {
    val inset = cell * 0.05f
    val side = cell - 2f * inset
    drawRoundRect(color, Offset(topLeft.x + inset, topLeft.y + inset), Size(side, side), CornerRadius(cell * 0.18f))
}

/** Floating "+score" text that rises and fades. Re-triggers whenever a new popup id arrives. */
@Composable
fun ScorePopupText(popup: ScorePopup, modifier: Modifier = Modifier) {
    key(popup.id) {
        val progress = remember { Animatable(0f) }
        LaunchedEffect(popup.id) { progress.animateTo(1f, tween(900)) }
        if (progress.value < 1f) {
            Text(
                text = popup.text,
                modifier = modifier.graphicsLayer {
                    translationY = -170f * progress.value
                    alpha = 1f - progress.value * progress.value
                    val s = 1f + 0.25f * (1f - progress.value)
                    scaleX = s
                    scaleY = s
                },
                color = MaterialTheme.colorScheme.primary,
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}
