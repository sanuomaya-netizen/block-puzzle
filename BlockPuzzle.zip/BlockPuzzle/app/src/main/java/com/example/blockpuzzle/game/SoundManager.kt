package com.example.blockpuzzle.game

import android.media.AudioManager
import android.media.ToneGenerator

/** Simple generated beeps via ToneGenerator, so no audio assets are needed. */
class SoundManager {
    private var tone: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 60)
    } catch (e: RuntimeException) {
        null
    }

    fun place() { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 70) }
    fun clear() { tone?.startTone(ToneGenerator.TONE_PROP_ACK, 180) }
    fun gameOver() { tone?.startTone(ToneGenerator.TONE_PROP_NACK, 350) }

    fun release() {
        tone?.release()
        tone = null
    }
}
