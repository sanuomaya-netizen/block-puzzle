package com.example.blockpuzzle

import android.app.Application
import com.example.blockpuzzle.ads.AppOpenAdManager
import com.google.android.gms.ads.MobileAds

class BlockPuzzleApp : Application() {
    val adManager = AppOpenAdManager()

    override fun onCreate() {
        super.onCreate()
        // Start loading the single App Open ad as early as possible.
        MobileAds.initialize(this) { adManager.load(this@BlockPuzzleApp) }
    }
}
