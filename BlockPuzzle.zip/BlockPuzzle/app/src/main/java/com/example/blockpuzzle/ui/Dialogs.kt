package com.example.blockpuzzle.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/** Game over: final score, best score, restart and menu. No ad, no revive prompt. */
@Composable
fun GameOverDialog(
    score: Int,
    highScore: Int,
    newRecord: Boolean,
    onPlayAgain: () -> Unit,
    onMainMenu: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { /* must choose a button */ },
        title = { Text("Game Over", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                if (newRecord) {
                    Text(
                        "New Record!",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                }
                Text("Score", style = MaterialTheme.typography.labelLarge)
                Text("$score", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Best: ${maxOf(highScore, score)}", style = MaterialTheme.typography.titleMedium)
            }
        },
        confirmButton = { Button(onClick = onPlayAgain) { Text("Play Again") } },
        dismissButton = { OutlinedButton(onClick = onMainMenu) { Text("Main Menu") } }
    )
}

@Composable
fun PauseDialog(onResume: () -> Unit, onRestart: () -> Unit, onMainMenu: () -> Unit) {
    AlertDialog(
        onDismissRequest = onResume,
        title = { Text("Paused", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                TextButton(onClick = onRestart) { Text("Restart") }
                TextButton(onClick = onMainMenu) { Text("Main Menu") }
            }
        },
        confirmButton = { Button(onClick = onResume) { Text("Resume") } }
    )
}
