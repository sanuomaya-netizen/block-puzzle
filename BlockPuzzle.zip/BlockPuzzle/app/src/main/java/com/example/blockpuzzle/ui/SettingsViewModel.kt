package com.example.blockpuzzle.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.blockpuzzle.data.AppSettings
import com.example.blockpuzzle.data.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)

    val settings: StateFlow<AppSettings> = repo.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    fun setTheme(name: String) { viewModelScope.launch { repo.setTheme(name) } }
    fun setSound(on: Boolean) { viewModelScope.launch { repo.setSoundEnabled(on) } }
    fun setVibration(on: Boolean) { viewModelScope.launch { repo.setVibrationEnabled(on) } }
    fun setMusic(on: Boolean) { viewModelScope.launch { repo.setMusicEnabled(on) } }
    fun resetHighScore() { viewModelScope.launch { repo.setHighScore(0) } }
}
