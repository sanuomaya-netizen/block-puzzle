package com.example.blockpuzzle.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class BlockTheme(
    val name: String,
    val accent: Color,
    val accentDark: Color,
    /** Five piece colours; piece colour index 1..5 maps to blocks[0..4]. */
    val blocks: List<Color>,
    val bgLight: Color,
    val bgDark: Color,
    val boardLight: Color,
    val boardDark: Color
)

object Themes {
    val all: List<BlockTheme> = listOf(
        BlockTheme(
            name = "Classic",
            accent = Color(0xFF5C6BC0), accentDark = Color(0xFF9FA8DA),
            blocks = listOf(Color(0xFFE57373), Color(0xFF64B5F6), Color(0xFF81C784), Color(0xFFFFD54F), Color(0xFFBA68C8)),
            bgLight = Color(0xFFF3F4FB), bgDark = Color(0xFF14152B),
            boardLight = Color(0xFFDDE0F0), boardDark = Color(0xFF24264A)
        ),
        BlockTheme(
            name = "Ocean",
            accent = Color(0xFF0288D1), accentDark = Color(0xFF4FC3F7),
            blocks = listOf(Color(0xFF0288D1), Color(0xFF26C6DA), Color(0xFF5C6BC0), Color(0xFF80DEEA), Color(0xFF26A69A)),
            bgLight = Color(0xFFE6F6FB), bgDark = Color(0xFF0B1F2A),
            boardLight = Color(0xFFC9E7F2), boardDark = Color(0xFF143447)
        ),
        BlockTheme(
            name = "Sunset",
            accent = Color(0xFFE64A19), accentDark = Color(0xFFFF8A65),
            blocks = listOf(Color(0xFFFF7043), Color(0xFFFFA726), Color(0xFFEF5350), Color(0xFFEC407A), Color(0xFFFFCA28)),
            bgLight = Color(0xFFFFF3E9), bgDark = Color(0xFF2B1510),
            boardLight = Color(0xFFF6DCCB), boardDark = Color(0xFF442620)
        ),
        BlockTheme(
            name = "Forest",
            accent = Color(0xFF2E7D32), accentDark = Color(0xFF81C784),
            blocks = listOf(Color(0xFF66BB6A), Color(0xFF9CCC65), Color(0xFF26A69A), Color(0xFF8D6E63), Color(0xFFD4E157)),
            bgLight = Color(0xFFEEF6EC), bgDark = Color(0xFF0F1F13),
            boardLight = Color(0xFFD2E5CE), boardDark = Color(0xFF1E3A24)
        ),
        BlockTheme(
            name = "Mono",
            accent = Color(0xFF616161), accentDark = Color(0xFFBDBDBD),
            blocks = listOf(Color(0xFF9E9E9E), Color(0xFF757575), Color(0xFFBDBDBD), Color(0xFF616161), Color(0xFF8A8A8A)),
            bgLight = Color(0xFFF2F2F2), bgDark = Color(0xFF121212),
            boardLight = Color(0xFFDADADA), boardDark = Color(0xFF2C2C2C)
        )
    )

    fun byName(name: String): BlockTheme = all.firstOrNull { it.name == name } ?: all.first()
}

@Composable
fun BlockPuzzleTheme(theme: BlockTheme, content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) {
        darkColorScheme(
            primary = theme.accentDark,
            onPrimary = Color(0xFF101010),
            background = theme.bgDark,
            surface = theme.bgDark,
            surfaceVariant = theme.boardDark,
            onBackground = Color(0xFFE6E1E5),
            onSurface = Color(0xFFE6E1E5)
        )
    } else {
        lightColorScheme(
            primary = theme.accent,
            onPrimary = Color.White,
            background = theme.bgLight,
            surface = theme.bgLight,
            surfaceVariant = theme.boardLight,
            onBackground = Color(0xFF1B1B1F),
            onSurface = Color(0xFF1B1B1F)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
