package com.example.blockpuzzle.game

import kotlin.random.Random

/** Pure game rules: no Android or Compose dependencies, so it is easy to unit test. */
object GameEngine {
    const val SIZE = 8
    const val COLOR_COUNT = 5
    private const val MAX_GENERATION_ATTEMPTS = 10

    fun emptyBoard(): Board = List(SIZE) { List(SIZE) { 0 } }

    fun canPlace(board: Board, shape: Shape, row: Int, col: Int): Boolean {
        for ((dr, dc) in shape.cells) {
            val r = row + dr
            val c = col + dc
            if (r !in 0 until SIZE || c !in 0 until SIZE) return false
            if (board[r][c] != 0) return false
        }
        return true
    }

    fun canPlaceAnywhere(board: Board, shape: Shape): Boolean {
        for (r in 0..SIZE - shape.height) {
            for (c in 0..SIZE - shape.width) {
                if (canPlace(board, shape, r, c)) return true
            }
        }
        return false
    }

    fun place(board: Board, piece: Piece, row: Int, col: Int): Board {
        val m = board.map { it.toMutableList() }
        for ((dr, dc) in piece.shape.cells) m[row + dr][col + dc] = piece.colorIdx
        return m
    }

    /** Returns the indices of completely filled rows and columns. */
    fun fullLines(board: Board): Pair<List<Int>, List<Int>> {
        val rows = (0 until SIZE).filter { r -> board[r].all { it != 0 } }
        val cols = (0 until SIZE).filter { c -> (0 until SIZE).all { r -> board[r][c] != 0 } }
        return rows to cols
    }

    /** Cell keys (row * SIZE + col) covered by the given rows and columns. */
    fun cellsOf(rows: List<Int>, cols: List<Int>): Set<Int> {
        val out = HashSet<Int>()
        for (r in rows) for (c in 0 until SIZE) out.add(r * SIZE + c)
        for (c in cols) for (r in 0 until SIZE) out.add(r * SIZE + c)
        return out
    }

    fun clear(board: Board, cells: Set<Int>): Board =
        List(SIZE) { r -> List(SIZE) { c -> if ((r * SIZE + c) in cells) 0 else board[r][c] } }

    private fun randomPiece(rnd: Random): Piece =
        Piece(Shapes.all[rnd.nextInt(Shapes.all.size)], 1 + rnd.nextInt(COLOR_COUNT))

    /**
     * Fair generation: at least one of the 3 pieces must fit on the current board.
     * Tries up to 10 random sets, then falls back to forcing a 1x1 piece into the set.
     */
    fun generateSet(board: Board, rnd: Random = Random.Default): List<Piece> {
        repeat(MAX_GENERATION_ATTEMPTS) {
            val set = List(3) { randomPiece(rnd) }
            if (set.any { canPlaceAnywhere(board, it.shape) }) return set
        }
        val forced = MutableList(3) { randomPiece(rnd) }
        forced[rnd.nextInt(3)] = Piece(Shapes.single, 1 + rnd.nextInt(COLOR_COUNT))
        return forced
    }
}
