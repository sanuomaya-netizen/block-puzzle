package com.example.blockpuzzle.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/**
 * Calm background music generated in code (no audio files needed).
 * A 4-chord loop (C - Am - F - G) with a soft arpeggio, bass and pad, played by a looping AudioTrack.
 */
class MusicPlayer {
    private var track: AudioTrack? = null
    private var building = false
    private var wantPlaying = false
    private var released = false

    @Synchronized
    fun start() {
        if (released) return
        wantPlaying = true
        val t = track
        if (t != null) {
            if (t.playState != AudioTrack.PLAYSTATE_PLAYING) t.play()
            return
        }
        if (building) return
        building = true
        Thread {
            val built = try { buildTrack() } catch (e: Exception) { null }
            synchronized(this) {
                building = false
                if (built == null) return@synchronized
                if (released) {
                    built.release()
                } else {
                    track = built
                    if (wantPlaying) built.play()
                }
            }
        }.start()
    }

    @Synchronized
    fun pause() {
        wantPlaying = false
        val t = track ?: return
        if (t.playState == AudioTrack.PLAYSTATE_PLAYING) t.pause()
    }

    @Synchronized
    fun release() {
        released = true
        wantPlaying = false
        track?.release()
        track = null
    }

    private fun buildTrack(): AudioTrack {
        val pcm = synthesize()
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t.setLoopPoints(0, pcm.size, -1)
        t.setVolume(0.35f)
        return t
    }

    private fun synthesize(): ShortArray {
        val beat = SAMPLE_RATE * 60 / BPM
        val total = beat * 16 // 4 bars of 4 beats
        val buf = FloatArray(total)

        // (bass, triad pad, arpeggio notes) per bar: C, Am, F, G
        val bars = listOf(
            Triple(36, intArrayOf(60, 64, 67), intArrayOf(60, 64, 67, 72)),
            Triple(33, intArrayOf(57, 60, 64), intArrayOf(57, 60, 64, 69)),
            Triple(29, intArrayOf(57, 60, 65), intArrayOf(57, 60, 65, 69)),
            Triple(31, intArrayOf(59, 62, 67), intArrayOf(59, 62, 67, 71))
        )
        val arpPattern = intArrayOf(0, 1, 2, 3, 2, 1, 2, 3)
        val eighth = beat / 2

        for ((barIdx, bar) in bars.withIndex()) {
            val barStart = barIdx * beat * 4
            // bass: one long soft note
            addNote(buf, barStart, bar.first + 12, beat * 4, 0.30f, attackMs = 25, decay = 1.2f, overtone = 0.1f)
            // pad: sustained triad with a smooth swell
            for (n in bar.second) addPad(buf, barStart, n - 12, beat * 4, 0.05f)
            // arpeggio: eighth notes that ring for about 1.5 beats
            for (i in 0 until 8) {
                val note = bar.third[arpPattern[i]]
                addNote(buf, barStart + i * eighth, note, (beat * 1.5f).toInt(), 0.16f, attackMs = 6, decay = 3.5f, overtone = 0.3f)
            }
        }

        var peak = 0f
        for (v in buf) peak = max(peak, abs(v))
        val scale = if (peak > 0f) 0.8f / peak else 1f
        return ShortArray(total) { (buf[it] * scale * Short.MAX_VALUE).toInt().toShort() }
    }

    /** Adds a decaying sine note; writes wrap around the end so the loop is seamless. */
    private fun addNote(
        buf: FloatArray, start: Int, midi: Int, length: Int, amp: Float,
        attackMs: Int, decay: Float, overtone: Float
    ) {
        val freq = 440.0 * 2.0.pow((midi - 69) / 12.0)
        val attack = SAMPLE_RATE * attackMs / 1000
        val w = 2.0 * PI * freq / SAMPLE_RATE
        for (i in 0 until length) {
            val env = (if (i < attack) i / attack.toFloat() else 1f) * exp(-decay * i / length).toFloat()
            val s = sin(w * i) + overtone * sin(2 * w * i) + overtone * 0.4 * sin(3 * w * i)
            buf[(start + i) % buf.size] += (s * env * amp).toFloat()
        }
    }

    private fun addPad(buf: FloatArray, start: Int, midi: Int, length: Int, amp: Float) {
        val freq = 440.0 * 2.0.pow((midi - 69) / 12.0)
        val w = 2.0 * PI * freq / SAMPLE_RATE
        for (i in 0 until length) {
            val env = sin(PI * i / length).toFloat() // swells in and out
            buf[(start + i) % buf.size] += (sin(w * i) * env * amp).toFloat()
        }
    }

    private companion object {
        const val SAMPLE_RATE = 22050
        const val BPM = 90
    }
}
