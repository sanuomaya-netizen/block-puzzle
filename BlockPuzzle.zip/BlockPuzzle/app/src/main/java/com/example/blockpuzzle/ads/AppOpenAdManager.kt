package com.example.blockpuzzle.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd

object AdConfig {
    // TODO: Replace with your REAL AdMob App Open ad unit ID before publishing.
    // (The real AdMob *App ID* goes in AndroidManifest.xml.)
    // Test App Open ad unit ID:
    const val APP_OPEN_AD_UNIT_ID = "ca-app-pub-3940256099942544/9257395921"
}

/**
 * Loads and shows a single App Open Ad. This is the ONLY ad in the app:
 * it can be shown at most once per process (see [hasShown]) and only from the splash screen.
 */
class AppOpenAdManager {
    @Volatile private var ad: AppOpenAd? = null
    @Volatile private var isLoading = false
    @Volatile private var hasShown = false

    /** True once the load attempt has finished, successfully or not. */
    @Volatile var loadFinished = false
        private set

    val adReady: Boolean get() = ad != null && !hasShown

    fun load(context: Context) {
        if (hasShown || ad != null || isLoading) return
        isLoading = true
        AppOpenAd.load(
            context.applicationContext,
            AdConfig.APP_OPEN_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(loaded: AppOpenAd) {
                    ad = loaded
                    isLoading = false
                    loadFinished = true
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null
                    isLoading = false
                    loadFinished = true
                }
            }
        )
    }

    /** Shows the ad if one is ready and none was shown this session; always calls [onFinished] exactly once. */
    fun showOnce(activity: Activity, onFinished: () -> Unit) {
        val current = ad
        if (hasShown || current == null) {
            onFinished()
            return
        }
        hasShown = true
        ad = null
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() = onFinished()
            override fun onAdFailedToShowFullScreenContent(adError: AdError) = onFinished()
        }
        current.show(activity)
    }
}
